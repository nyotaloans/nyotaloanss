<?php
require 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
  header("Location: index.html");
  exit();
}

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Validate input
  if (!isset($_POST['loan_amount']) || empty($_POST['loan_amount'])) {
    $error = "Loan amount is required.";
  } else {
    $amount = filter_var($_POST['loan_amount'], FILTER_VALIDATE_FLOAT);
    
    if ($amount === false) {
      $error = "Invalid loan amount. Please enter a valid number.";
    } elseif ($amount < 1000) {
      $error = "Minimum loan amount is KSh 1,000.";
    } elseif ($amount > 100000) {
      $error = "Maximum loan amount is KSh 100,000.";
    } else {
      $user_id = $_SESSION['user_id'];
      $date = date('Y-m-d');

      // Prepare and execute query
      $stmt = $conn->prepare("INSERT INTO loans (user_id, loan_amount, loan_date, status) VALUES (?, ?, ?, 'Pending')");
      
      if (!$stmt) {
        $error = "Error preparing query: " . $conn->error;
      } else {
        $stmt->bind_param("ids", $user_id, $amount, $date);
        
        if ($stmt->execute()) {
          $success = true;
          $stmt->close();
          // Redirect after successful submission
          header("Location: dashboard.php?success=loan_submitted");
          exit();
        } else {
          $error = "Error submitting loan application. Please try again.";
          $stmt->close();
        }
      }
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Loan Request - NYOTA LOANS</title>
  <style>
    body {
      font-family: "Segoe UI", Arial, sans-serif;
      background-color: #f4f6fa;
      margin: 0;
      padding: 20px;
    }
    .container {
      max-width: 500px;
      margin: 50px auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    h2 {
      color: #003366;
      text-align: center;
      margin-bottom: 25px;
    }
    .form-group {
      margin-bottom: 20px;
    }
    label {
      display: block;
      margin-bottom: 8px;
      font-weight: bold;
      color: #333;
    }
    input[type="number"] {
      width: 100%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 16px;
      box-sizing: border-box;
    }
    input[type="number"]:focus {
      outline: none;
      border-color: #0066cc;
    }
    .error {
      background-color: #fee;
      color: #c00;
      padding: 10px;
      border-radius: 6px;
      margin-bottom: 15px;
      border-left: 4px solid #c00;
    }
    button {
      width: 100%;
      padding: 12px;
      background-color: #0066cc;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      font-weight: bold;
    }
    button:hover {
      background-color: #0052a3;
    }
    .back-link {
      display: block;
      text-align: center;
      margin-top: 15px;
      color: #0066cc;
      text-decoration: none;
    }
    .back-link:hover {
      text-decoration: underline;
    }
    .info {
      background-color: #e3f2fd;
      color: #1976d2;
      padding: 10px;
      border-radius: 6px;
      margin-bottom: 15px;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Loan Request</h2>
    
    <?php if ($error): ?>
      <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <div class="info">
      <strong>Loan Information:</strong><br>
      Minimum: KSh 1,000<br>
      Maximum: KSh 100,000<br>
      Step: KSh 500
    </div>
    
    <form method="POST" action="">
      <div class="form-group">
        <label for="loan_amount">Loan Amount (KSh):</label>
        <input 
          type="number" 
          id="loan_amount" 
          name="loan_amount" 
          required 
          min="1000" 
          max="100000" 
          step="500"
          placeholder="Enter amount (e.g., 5000)"
          value="<?php echo isset($_POST['loan_amount']) ? htmlspecialchars($_POST['loan_amount']) : ''; ?>"
        >
      </div>
      
      <button type="submit">Submit Request</button>
    </form>
    
    <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
  </div>
</body>
</html>
<?php
// Clean up resources
if (isset($conn)) {
  $conn->close();
}
?>

