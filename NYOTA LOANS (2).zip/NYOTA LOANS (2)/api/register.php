<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require '../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$required_fields = ['firstName', 'surname', 'dob', 'phone', 'country', 'nokName', 'nokPhone', 'email', 'password'];

foreach ($required_fields as $field) {
    if (!isset($data[$field]) || empty(trim($data[$field]))) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => "Field '$field' is required"]);
        exit;
    }
}

$first = trim($data['firstName']);
$second = isset($data['secondName']) ? trim($data['secondName']) : '';
$surname = trim($data['surname']);
$dob = trim($data['dob']);
$phone = trim($data['phone']);
$country = trim($data['country']);
$nokName = trim($data['nokName']);
$nokPhone = trim($data['nokPhone']);
$email = trim($data['email']);
$password = $data['password'];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

if (strlen($password) < 6) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters long']);
    exit;
}

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dob)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid date format. Use YYYY-MM-DD']);
    exit;
}

if (!preg_match('/^\+?\d{10,15}$/', $phone)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid phone number format']);
    exit;
}

if (!preg_match('/^\+?\d{10,15}$/', $nokPhone)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid next of kin phone number format']);
    exit;
}

// Check if email already exists
$check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$check_stmt->bind_param("s", $email);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows > 0) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => 'Email already registered']);
    $check_stmt->close();
    $conn->close();
    exit;
}
$check_stmt->close();

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$role = 'user';

// Insert user
$stmt = $conn->prepare("INSERT INTO users (first_name, second_name, surname, dob, phone, country, nok_name, nok_phone, email, password, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    exit;
}

$stmt->bind_param("sssssssssss", $first, $second, $surname, $dob, $phone, $country, $nokName, $nokPhone, $email, $hashed_password, $role);

if ($stmt->execute()) {
    $user_id = $conn->insert_id;
    
    // Fetch created user (without password)
    $user_query = $conn->prepare("SELECT id, first_name, second_name, surname, dob, phone, country, nok_name, nok_phone, email, role, created_at FROM users WHERE id = ?");
    $user_query->bind_param("i", $user_id);
    $user_query->execute();
    $user_result = $user_query->get_result();
    $user = $user_result->fetch_assoc();
    $user_query->close();
    
    echo json_encode([
        'success' => true,
        'message' => 'Registration successful',
        'user' => $user
    ]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Registration failed: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>

