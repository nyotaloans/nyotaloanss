<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require '../config.php';

// Get user ID from Authorization header or request
$user_id = null;
if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
    $auth = $_SERVER['HTTP_AUTHORIZATION'];
    $user_id = str_replace('Bearer ', '', $auth);
} elseif (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $user_id = $data['user_id'] ?? null;
}

if (!$user_id) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'User ID required']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get user loans
    $stmt = $conn->prepare("SELECT * FROM loans WHERE user_id = ? ORDER BY loan_date DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $loans = [];
    while ($row = $result->fetch_assoc()) {
        $loans[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'loans' => $loans
    ]);
    
    $stmt->close();
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Create new loan
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['loan_amount']) || empty($data['loan_amount'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Loan amount is required']);
        exit;
    }
    
    $amount = filter_var($data['loan_amount'], FILTER_VALIDATE_FLOAT);
    
    if ($amount === false) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid loan amount']);
        exit;
    }
    
    if ($amount < 1000) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Minimum loan amount is KSh 1,000']);
        exit;
    }
    
    if ($amount > 100000) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Maximum loan amount is KSh 100,000']);
        exit;
    }
    
    $date = date('Y-m-d');
    $status = 'Pending';
    
    $stmt = $conn->prepare("INSERT INTO loans (user_id, loan_amount, loan_date, status) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ids", $user_id, $amount, $date, $status);
    
    if ($stmt->execute()) {
        $loan_id = $conn->insert_id;
        echo json_encode([
            'success' => true,
            'message' => 'Loan application submitted successfully',
            'loan_id' => $loan_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error submitting loan: ' . $stmt->error]);
    }
    
    $stmt->close();
}

$conn->close();
?>

