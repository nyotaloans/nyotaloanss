<?php
/**
 * Smart Chrism Shop – Automatic Setup
 * -----------------------------------
 * Creates database, tables, and inserts sample data
 * Works with XAMPP or hosted MySQL
 */

$host = "localhost";
$user = "root";          // Default XAMPP username
$pass = "";              // Leave blank unless you set a password
$dbname = "smart_chrism_shop";

try {
    // Connect to MySQL server
    $conn = new mysqli($host, $user, $pass);

    if ($conn->connect_error) {
        die("<h2>❌ Database connection failed: " . $conn->connect_error . "</h2>");
    }

    // Create database if not exists
    $conn->query("CREATE DATABASE IF NOT EXISTS $dbname");
    $conn->select_db($dbname);

    // --- Create tables ---
    $queries = [

        // Admins
        "CREATE TABLE IF NOT EXISTS admins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(150) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",

        // Categories
        "CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",

        // Products
        "CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(150) NOT NULL,
            description TEXT,
            price DECIMAL(10,2) NOT NULL,
            category_id INT,
            image VARCHAR(255),
            stock INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
        )",

        // Orders
        "CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            customer_name VARCHAR(100),
            customer_email VARCHAR(150),
            total DECIMAL(10,2),
            payment_method VARCHAR(50),
            status ENUM('Pending','Paid','Shipped','Completed','Cancelled') DEFAULT 'Pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",

        // Order Items
        "CREATE TABLE IF NOT EXISTS order_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT,
            product_id INT,
            quantity INT DEFAULT 1,
            price DECIMAL(10,2),
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
        )",

        // Analytics
        "CREATE TABLE IF NOT EXISTS analytics (
            id INT AUTO_INCREMENT PRIMARY KEY,
            metric VARCHAR(50),
            value INT,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )"
    ];

    foreach ($queries as $sql) {
        $conn->query($sql);
    }

    // Insert default admin if none exists
    $conn->query("INSERT IGNORE INTO admins (id, name, email, password)
                  VALUES (1, 'Smart Admin', 'brianmoses237@gmail.com', MD5('admin123'))");

    // Insert default categories
    $conn->query("INSERT IGNORE INTO categories (id, name) VALUES
        (1, 'Running'), (2, 'Casual'), (3, 'Basketball'), (4, 'Training')");

    // Insert sample products
    $conn->query("INSERT IGNORE INTO products (id, name, description, price, category_id, image, stock) VALUES
        (1, 'Nike Air Max', 'Lightweight running shoe with superior cushioning', 120.00, 1, 'uploads/nike_air_max.jpg', 50),
        (2, 'Adidas Ultraboost', 'Comfort running shoe with boost sole', 140.00, 1, 'uploads/adidas_ultraboost.jpg', 35),
        (3, 'Converse All Star', 'Classic casual sneaker', 65.00, 2, 'uploads/converse_allstar.jpg', 75),
        (4, 'Puma Drift Cat', 'Low-profile motorsport-inspired casual shoe', 80.00, 2, 'uploads/puma_driftcat.jpg', 40),
        (5, 'Jordan Retro 4', 'Premium basketball shoe', 200.00, 3, 'uploads/jordan_retro4.jpg', 20)");

    // Insert default analytics
    $conn->query("INSERT IGNORE INTO analytics (id, metric, value) VALUES
        (1, 'Sales', 540),
        (2, 'Users', 230),
        (3, 'Inventory', 520)");

    echo "<h2>✅ Smart Chrism Shop database setup complete!</h2>";
    echo "<p>Default admin login:</p>";
    echo "<b>Email:</b> brianmoses237@gmail.com<br>";
    echo "<b>Password:</b> admin123<br><br>";
    echo "<p>Redirecting to Admin Dashboard...</p>";
    echo "<script>setTimeout(()=>{window.location.href='admin/dashboard.php';},4000);</script>";

} catch (Exception $e) {
    echo "<h2>⚠️ Setup error: " . $e->getMessage() . "</h2>";
}

$conn->close();
?>
