<?php
require 'config.php';
session_start();

$error = '';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
  if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header("Location: admin.php");
  } else {
    header("Location: dashboard.php");
  }
  exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Validate input
  if (!isset($_POST['loginEmail']) || !isset($_POST['loginPassword'])) {
    $error = "All fields are required.";
  } else {
    $email = trim($_POST['loginEmail']);
    $password = $_POST['loginPassword'];

    // Validate email format
    if (empty($email) || empty($password)) {
      $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $error = "Invalid email format.";
    } else {
      // Prepare and execute query
      $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
      
      if (!$stmt) {
        $error = "Error preparing query: " . $conn->error;
      } else {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
          $user = $result->fetch_assoc();
          
          // Verify password
          if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['first_name'];
            $_SESSION['role'] = $user['role'] ?? 'user';

            $stmt->close();
            $conn->close();
            
            // Redirect based on role
            if ($_SESSION['role'] === 'admin') {
              header("Location: admin.php");
            } else {
              header("Location: dashboard.php");
            }
            exit();
          } else {
            $error = "Incorrect password.";
          }
        } else {
          $error = "No user found with that email.";
        }
        
        $stmt->close();
      }
    }
  }
}

// Handle errors - redirect back to login page with error
if ($error && $_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($conn)) {
    $conn->close();
  }
  header("Location: NYOTA LOANS.HTML?error=" . urlencode($error));
  exit();
}

// Clean up resources for GET requests
if (isset($conn)) {
  $conn->close();
}
?>
