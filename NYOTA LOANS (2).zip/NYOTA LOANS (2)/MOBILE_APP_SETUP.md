# NYOTA LOANS Mobile App Setup Guide

## Overview

A complete React Native mobile application has been created for the NYOTA LOANS platform. The app includes:

- User authentication (Login/Register)
- User dashboard with profile information
- Loan application submission
- Loan history viewing

## Project Structure

```
NYOTA LOANS (2)/
├── api/                    # REST API endpoints for mobile app
│   ├── login.php
│   ├── register.php
│   ├── loans.php
│   └── user.php
└── mobile-app/             # React Native mobile application
    ├── App.js
    ├── config.js
    ├── package.json
    ├── screens/
    │   ├── LoginScreen.js
    │   ├── RegisterScreen.js
    │   ├── DashboardScreen.js
    │   ├── LoanApplicationScreen.js
    │   └── LoadingScreen.js
    └── services/
        └── api.js
```

## Quick Start

### 1. Install Prerequisites

- **Node.js** (v14 or higher): Download from [nodejs.org](https://nodejs.org/)
- **Expo CLI**: Install globally with `npm install -g expo-cli`
- **Expo Go App**: Install on your phone from App Store (iOS) or Google Play (Android)

### 2. Setup Mobile App

```bash
# Navigate to mobile app directory
cd mobile-app

# Install dependencies
npm install
```

### 3. Configure API URL

Edit `mobile-app/config.js` and update the `API_BASE_URL`:

- **For Android Emulator**: `http://10.0.2.2/NYOTA%20LOANS%20(2)/api`
- **For iOS Simulator**: `http://localhost/NYOTA%20LOANS%20(2)/api`
- **For Physical Device**: `http://YOUR_COMPUTER_IP/NYOTA%20LOANS%20(2)/api`

To find your computer's IP:
- **Windows**: Run `ipconfig` in Command Prompt, look for IPv4 Address
- **Mac/Linux**: Run `ifconfig` in Terminal, look for inet address

### 4. Start the App

```bash
# From mobile-app directory
npm start
```

This will:
- Start the Expo development server
- Open Expo Developer Tools in your browser
- Display a QR code

### 5. Run on Device/Emulator

**Option A: Physical Device**
1. Install Expo Go app on your phone
2. Scan the QR code displayed in terminal/browser
3. App will load on your device

**Option B: Android Emulator**
1. Start Android Studio and launch an emulator
2. Press `a` in the terminal where Expo is running

**Option C: iOS Simulator** (Mac only)
1. Press `i` in the terminal where Expo is running

## API Endpoints

The mobile app uses these REST API endpoints:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/login.php` | POST | User login |
| `/api/register.php` | POST | User registration |
| `/api/loans.php?user_id={id}` | GET | Get user's loans |
| `/api/loans.php` | POST | Submit loan application |
| `/api/user.php?user_id={id}` | GET | Get user profile |

All endpoints return JSON responses and support CORS for mobile app access.

## Features

### Authentication
- Secure login with email and password
- User registration with validation
- Session management using AsyncStorage

### Dashboard
- View user profile information
- Display loan history
- Pull-to-refresh functionality
- Quick loan application button

### Loan Application
- Form validation
- Amount limits (KSh 1,000 - KSh 100,000)
- Real-time status updates

## Troubleshooting

### Connection Issues

**Problem**: "Network request failed" or "Cannot connect to server"

**Solutions**:
1. Verify XAMPP is running (Apache and MySQL)
2. Check `API_BASE_URL` in `config.js`
3. Ensure phone/emulator and computer are on same network (for physical device)
4. Check firewall settings - allow port 80
5. Try accessing API URL in browser first

### CORS Errors

The API endpoints already include CORS headers. If you still see CORS errors:
1. Check that API files are in the correct location
2. Verify Apache is serving PHP files correctly

### Module Not Found Errors

```bash
cd mobile-app
rm -rf node_modules
npm install
```

### Expo Issues

If Expo CLI is not recognized:
```bash
npm install -g expo-cli
```

## Building for Production

### Android APK

```bash
cd mobile-app
expo build:android
```

### iOS App

```bash
cd mobile-app
expo build:ios
```

Note: iOS builds require an Apple Developer account.

## Testing Checklist

- [ ] User can register with valid information
- [ ] User can login with registered credentials
- [ ] Dashboard displays user profile correctly
- [ ] Loan application form validates input
- [ ] Loan applications are submitted successfully
- [ ] Loan history displays correctly
- [ ] Logout functionality works
- [ ] Pull-to-refresh works on dashboard

## Next Steps

1. Add app icons and splash screens to `mobile-app/assets/`
2. Configure app.json with your app details
3. Test on both iOS and Android devices
4. Set up push notifications (optional)
5. Add biometric authentication (optional)
6. Implement offline mode (optional)

## Support

For issues or questions:
1. Check the mobile-app/README.md for detailed documentation
2. Review Expo documentation: https://docs.expo.dev/
3. Check React Navigation docs: https://reactnavigation.org/

