<?php
require 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Validate required fields
  $required_fields = ['firstName', 'surname', 'dob', 'phone', 'country', 'nokName', 'nokPhone', 'email', 'password'];
  
  foreach ($required_fields as $field) {
    if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
      $error = "All required fields must be filled.";
      break;
    }
  }

  if (!$error) {
    // Sanitize and validate input
    $first = trim($_POST['firstName']);
    $second = isset($_POST['secondName']) ? trim($_POST['secondName']) : '';
    $surname = trim($_POST['surname']);
    $dob = trim($_POST['dob']);
    $phone = trim($_POST['phone']);
    $country = trim($_POST['country']);
    $nokName = trim($_POST['nokName']);
    $nokPhone = trim($_POST['nokPhone']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $error = "Invalid email format.";
    }
    // Validate password length
    elseif (strlen($password) < 6) {
      $error = "Password must be at least 6 characters long.";
    }
    // Validate date of birth
    elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dob)) {
      $error = "Invalid date format.";
    }
    // Validate phone number (basic check)
    elseif (!preg_match('/^\+?\d{10,15}$/', $phone)) {
      $error = "Invalid phone number format.";
    }
    elseif (!preg_match('/^\+?\d{10,15}$/', $nokPhone)) {
      $error = "Invalid next of kin phone number format.";
    }
    else {
      // Check if email already exists
      $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
      
      if (!$check_stmt) {
        $error = "Error preparing query: " . $conn->error;
      } else {
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $result = $check_stmt->get_result();

        if ($result->num_rows > 0) {
          $error = "Email already registered.";
          $check_stmt->close();
        } else {
          $check_stmt->close();

          // Hash password
          $hashed_password = password_hash($password, PASSWORD_DEFAULT);
          
          // Default role to 'user'
          $role = 'user';

          // Prepare and execute insert query
          $stmt = $conn->prepare("INSERT INTO users 
            (first_name, second_name, surname, dob, phone, country, nok_name, nok_phone, email, password, role) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
          
          if (!$stmt) {
            $error = "Error preparing query: " . $conn->error;
          } else {
            $stmt->bind_param("sssssssssss", $first, $second, $surname, $dob, $phone, $country, $nokName, $nokPhone, $email, $hashed_password, $role);

            if ($stmt->execute()) {
              $stmt->close();
              $conn->close();
              // Redirect to login page with success message
              header("Location: NYOTA LOANS.HTML?success=Registration successful! Please login.");
              exit();
            } else {
              $error = "Registration failed. Please try again.";
              $stmt->close();
            }
          }
        }
      }
    }
  }

  // If there's an error, redirect back with error message
  if ($error) {
    header("Location: NYOTA LOANS.HTML?error=" . urlencode($error));
    exit();
  }
}

// Clean up resources
if (isset($conn)) {
  $conn->close();
}
?>
