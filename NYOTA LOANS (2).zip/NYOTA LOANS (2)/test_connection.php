<?php
/**
 * Database Connection Test Script
 * This file tests the connection to MySQL database on localhost
 */

// Database connection settings for localhost (XAMPP)
$host = "localhost";
$username = "root";  // XAMPP default MySQL username
$password = "";      // XAMPP default MySQL password (empty)
$database = "records_db"; // Change to your database name

echo "<h2>Testing Database Connection to Localhost</h2>";
echo "<hr>";

// Test 1: Connect to MySQL server
echo "<h3>Test 1: Connecting to MySQL Server</h3>";
$conn = new mysqli($host, $username, $password);

if ($conn->connect_errno) {
    echo "<p style='color: red;'>❌ Connection failed: " . $conn->connect_error . "</p>";
    echo "<p><strong>Possible solutions:</strong></p>";
    echo "<ul>";
    echo "<li>Make sure MySQL/MariaDB is running in XAMPP</li>";
    echo "<li>Check if MySQL service is started in XAMPP Control Panel</li>";
    echo "<li>Verify username and password are correct</li>";
    echo "</ul>";
    exit();
} else {
    echo "<p style='color: green;'>✅ Successfully connected to MySQL server!</p>";
    echo "<p><strong>MySQL Version:</strong> " . $conn->server_info . "</p>";
}

// Test 2: Check if database exists
echo "<hr>";
echo "<h3>Test 2: Checking Database</h3>";
$db_check = $conn->query("SHOW DATABASES LIKE '$database'");

if ($db_check && $db_check->num_rows > 0) {
    echo "<p style='color: green;'>✅ Database '$database' exists!</p>";
    $conn->select_db($database);
} else {
    echo "<p style='color: orange;'>⚠️ Database '$database' does not exist.</p>";
    echo "<p>Creating database...</p>";
    
    $create_db = "CREATE DATABASE IF NOT EXISTS $database CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    if ($conn->query($create_db)) {
        echo "<p style='color: green;'>✅ Database '$database' created successfully!</p>";
        $conn->select_db($database);
    } else {
        echo "<p style='color: red;'>❌ Error creating database: " . $conn->error . "</p>";
    }
}

// Test 3: Check charset
echo "<hr>";
echo "<h3>Test 3: Setting Character Set</h3>";
if ($conn->set_charset("utf8mb4")) {
    echo "<p style='color: green;'>✅ Character set set to utf8mb4</p>";
} else {
    echo "<p style='color: red;'>❌ Error setting character set: " . $conn->error . "</p>";
}

// Test 4: Check if users table exists
echo "<hr>";
echo "<h3>Test 4: Checking Tables</h3>";
$tables = $conn->query("SHOW TABLES");

if ($tables && $tables->num_rows > 0) {
    echo "<p style='color: green;'>✅ Found " . $tables->num_rows . " table(s):</p>";
    echo "<ul>";
    while ($row = $tables->fetch_array()) {
        echo "<li>" . $row[0] . "</li>";
    }
    echo "</ul>";
} else {
    echo "<p style='color: orange;'>⚠️ No tables found in database.</p>";
    echo "<p>You may need to create the required tables (users, loans, etc.)</p>";
}

// Test 5: Connection info
echo "<hr>";
echo "<h3>Test 5: Connection Information</h3>";
echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
echo "<tr><th>Property</th><th>Value</th></tr>";
echo "<tr><td>Host</td><td>" . $conn->host_info . "</td></tr>";
echo "<tr><td>Server Info</td><td>" . $conn->server_info . "</td></tr>";
echo "<tr><td>Protocol Version</td><td>" . $conn->protocol_version . "</td></tr>";
echo "<tr><td>Client Info</td><td>" . $conn->client_info . "</td></tr>";
echo "<tr><td>Character Set</td><td>" . $conn->character_set_name() . "</td></tr>";
echo "</table>";

// Close connection
$conn->close();

echo "<hr>";
echo "<p style='color: green;'><strong>✅ All tests completed!</strong></p>";
echo "<p>If all tests passed, your database connection is working correctly.</p>";
?>

