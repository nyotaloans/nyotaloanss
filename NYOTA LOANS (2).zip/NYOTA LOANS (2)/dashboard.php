<?php
require 'config.php';
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
  header("Location: index.html");
  exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user profile
$user_query = $conn->prepare("SELECT * FROM users WHERE id = ?");
if (!$user_query) {
  die("Error preparing query: " . $conn->error);
}

$user_query->bind_param("i", $user_id);
$user_query->execute();
$user_result = $user_query->get_result();

if (!$user_result) {
  die("Error executing query: " . $conn->error);
}

$user = $user_result->fetch_assoc();

// Check if user exists
if (!$user) {
  session_destroy();
  header("Location: index.html");
  exit();
}

// Fetch user loans
$loan_query = $conn->prepare("SELECT * FROM loans WHERE user_id = ? ORDER BY loan_date DESC");
if (!$loan_query) {
  die("Error preparing query: " . $conn->error);
}

$loan_query->bind_param("i", $user_id);
$loan_query->execute();
$loans = $loan_query->get_result();

if (!$loans) {
  die("Error executing query: " . $conn->error);
}

$hasLoans = $loans->num_rows > 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Dashboard</title>
<style>
  body {
    font-family: "Segoe UI", sans-serif;
    background-color: #f4f6fa;
    margin: 0;
    padding: 0;
  }
  header {
    background-color: #003366;
    color: white;
    padding: 15px 30px;
    text-align: center;
  }
  .container {
    display: flex;
    flex-direction: column;
    max-width: 900px;
    margin: 30px auto;
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  }
  h2 {
    color: #003366;
    border-bottom: 2px solid #0066cc;
    padding-bottom: 6px;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
  }
  th, td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
  }
  th {
    background-color: #0066cc;
    color: white;
  }
  tr:nth-child(even) { background-color: #f2f2f2; }
  .logout {
    text-decoration: none;
    background: #cc0000;
    color: white;
    padding: 10px 20px;
    border-radius: 6px;
    text-align: center;
    display: inline-block;
    margin-top: 15px;
  }
  .apply-loan {
    text-decoration: none;
    background: #0066cc;
    color: white;
    padding: 10px 20px;
    border-radius: 6px;
    text-align: center;
    display: inline-block;
    margin-top: 15px;
  }
</style>
</head>
<body>
<header>
  <h1>Welcome, <?php echo htmlspecialchars($user['first_name']); ?>!</h1>
</header>

<div class="container">
  <section>
    <h2>Your Profile</h2>
    <p><strong>Full Name:</strong> <?php echo htmlspecialchars(trim($user['first_name'] . " " . $user['second_name'] . " " . $user['surname'])); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
    <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone'] ?? 'N/A'); ?></p>
    <p><strong>Country:</strong> <?php echo htmlspecialchars($user['country'] ?? 'N/A'); ?></p>
  </section>

  <section>
    <h2>Your Loans</h2>
    <?php if ($hasLoans): ?>
      <table>
        <tr>
          <th>Loan Amount (KSh)</th>
          <th>Date Applied</th>
          <th>Status</th>
        </tr>
        <?php while ($loan = $loans->fetch_assoc()): ?>
        <tr>
          <td><?php echo number_format((float)$loan['loan_amount'], 2); ?></td>
          <td><?php echo htmlspecialchars($loan['loan_date'] ?? 'N/A'); ?></td>
          <td>
            <?php 
              $status = htmlspecialchars($loan['status'] ?? 'Pending');
              $color = $status == 'Approved' ? 'green' : 
                       ($status == 'Rejected' ? 'red' : 'orange');
              echo "<span style='color:$color; font-weight:bold;'>" . $status . "</span>";
            ?>
          </td>
        </tr>
        <?php endwhile; ?>
      </table>
    <?php else: ?>
      <p>No loan records found.</p>
    <?php endif; ?>

    <a href="loan aplication.php" class="apply-loan">Apply for New Loan</a>
  </section>

  <a href="logout.php" class="logout">Logout</a>
</div>
</body>
</html>
<?php
// Clean up resources
$user_query->close();
$loan_query->close();
$conn->close();
?>
