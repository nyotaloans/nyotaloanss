<?php
$host = "localhost";
$user = "root"; // your MySQL username
$pass = "";     // your MySQL password (empty in XAMPP)
$db   = "records_db";

// Try to connect to MySQL server first (without database)
$conn = new mysqli($host, $user, $pass);

// Check connection
if ($conn->connect_errno) {
  die("Database connection failed: " . $conn->connect_error);
}

// Select database, create if it doesn't exist
try {
  $conn->select_db($db);
} catch (mysqli_sql_exception $e) {
  // If database doesn't exist, create it
  $db_escaped = $conn->real_escape_string($db);
  $create_db = "CREATE DATABASE IF NOT EXISTS `$db_escaped` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
  if ($conn->query($create_db)) {
    $conn->select_db($db);
  } else {
    die("Error creating database: " . $conn->error);
  }
}

// Set charset to UTF-8 to prevent encoding issues
$conn->set_charset("utf8mb4");

// Create users table if it doesn't exist
$create_users_table = "CREATE TABLE IF NOT EXISTS `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(100) NOT NULL,
  `second_name` VARCHAR(100) DEFAULT NULL,
  `surname` VARCHAR(100) NOT NULL,
  `dob` DATE NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `country` VARCHAR(100) NOT NULL,
  `nok_name` VARCHAR(100) NOT NULL,
  `nok_phone` VARCHAR(20) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(20) DEFAULT 'user',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (!$conn->query($create_users_table)) {
  die("Error creating users table: " . $conn->error);
}

// Create loans table if it doesn't exist
$create_loans_table = "CREATE TABLE IF NOT EXISTS `loans` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `loan_amount` DECIMAL(10,2) NOT NULL,
  `loan_date` DATE NOT NULL,
  `status` VARCHAR(20) DEFAULT 'Pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (!$conn->query($create_loans_table)) {
  die("Error creating loans table: " . $conn->error);
}
?>
