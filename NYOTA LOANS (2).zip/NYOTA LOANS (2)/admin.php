<?php
require 'config.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  header("Location: NYOTA LOANS.HTML");
  exit();
}

// Fetch all users
$result = $conn->query("SELECT id, first_name, second_name, surname, email, phone, country, nok_name, nok_phone, role FROM users ORDER BY id DESC");

if (!$result) {
  die("Error executing query: " . $conn->error);
}

$hasUsers = $result->num_rows > 0;
$userCount = $result->num_rows;

// Fetch all loans for admin view
$loans_result = $conn->query("SELECT l.id, l.user_id, l.loan_amount, l.loan_date, l.status, u.first_name, u.surname, u.email FROM loans l JOIN users u ON l.user_id = u.id ORDER BY l.loan_date DESC");

if (!$loans_result) {
  $loans_result = null;
  $hasLoans = false;
  $loanCount = 0;
} else {
  $hasLoans = $loans_result->num_rows > 0;
  $loanCount = $loans_result->num_rows;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel - NYOTA LOANS</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6fa;
      padding: 20px;
    }
    h2 {
      color: #003366;
      text-align: center;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      border-radius: 8px;
      overflow: hidden;
      margin-bottom: 20px;
    }
    th, td {
      border: 1px solid #ccc;
      padding: 10px;
      text-align: left;
      font-size: 14px;
    }
    th {
      background: #0066cc;
      color: white;
    }
    tr:nth-child(even) {
      background: #f2f2f2;
    }
    .logout {
      display: block;
      margin-top: 20px;
      text-align: center;
      text-decoration: none;
      color: white;
      background: #cc0000;
      padding: 10px 20px;
      border-radius: 6px;
      width: 120px;
      margin-left: auto;
      margin-right: auto;
    }
    .no-users, .no-loans {
      text-align: center;
      padding: 20px;
      background: white;
      border-radius: 8px;
      color: #666;
    }
    .stats {
      display: flex;
      gap: 20px;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }
    .stat-card {
      flex: 1;
      min-width: 200px;
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .stat-card h3 {
      margin: 0 0 10px 0;
      color: #003366;
      font-size: 18px;
    }
    .stat-card .number {
      font-size: 32px;
      font-weight: bold;
      color: #0066cc;
    }
    .section {
      margin-bottom: 30px;
    }
    .section-title {
      color: #003366;
      margin-bottom: 15px;
      font-size: 20px;
    }
    .status-badge {
      padding: 4px 8px;
      border-radius: 4px;
      font-weight: bold;
      font-size: 12px;
    }
    .status-pending {
      background: #fff3cd;
      color: #856404;
    }
    .status-approved {
      background: #d4edda;
      color: #155724;
    }
    .status-rejected {
      background: #f8d7da;
      color: #721c24;
    }
    @media (max-width: 768px) {
      table {
        font-size: 12px;
      }
      th, td {
        padding: 8px;
      }
      .stats {
        flex-direction: column;
      }
    }
  </style>
</head>
<body>
  <h2>Admin Panel – NYOTA LOANS</h2>
  
  <div class="stats">
    <div class="stat-card">
      <h3>Total Users</h3>
      <div class="number"><?php echo $userCount; ?></div>
    </div>
    <div class="stat-card">
      <h3>Total Loans</h3>
      <div class="number"><?php echo $loanCount; ?></div>
    </div>
  </div>

  <div class="section">
    <h3 class="section-title">Registered Users</h3>
    <?php if ($hasUsers): ?>
    <table>
      <tr>
        <th>ID</th>
        <th>Full Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Country</th>
        <th>Next of Kin</th>
        <th>Role</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?php echo htmlspecialchars($row['id']); ?></td>
        <td><?php echo htmlspecialchars(trim($row['first_name'] . " " . ($row['second_name'] ?? '') . " " . $row['surname'])); ?></td>
        <td><?php echo htmlspecialchars($row['email']); ?></td>
        <td><?php echo htmlspecialchars($row['phone'] ?? 'N/A'); ?></td>
        <td><?php echo htmlspecialchars($row['country'] ?? 'N/A'); ?></td>
        <td><?php 
          $nok = trim(($row['nok_name'] ?? '') . " (" . ($row['nok_phone'] ?? '') . ")");
          echo htmlspecialchars($nok !== " ()" ? $nok : 'N/A');
        ?></td>
        <td><?php echo htmlspecialchars(ucfirst($row['role'] ?? 'user')); ?></td>
      </tr>
      <?php endwhile; ?>
    </table>
    <?php else: ?>
    <div class="no-users">
      <p>No users registered yet.</p>
    </div>
    <?php endif; ?>
  </div>

  <?php if ($loans_result): ?>
  <div class="section">
    <h3 class="section-title">Loan Applications</h3>
    <?php if ($hasLoans): ?>
    <table>
      <tr>
        <th>Loan ID</th>
        <th>User</th>
        <th>Email</th>
        <th>Amount (KSh)</th>
        <th>Date Applied</th>
        <th>Status</th>
      </tr>
      <?php while ($loan = $loans_result->fetch_assoc()): ?>
      <tr>
        <td><?php echo htmlspecialchars($loan['id']); ?></td>
        <td><?php echo htmlspecialchars($loan['first_name'] . " " . $loan['surname']); ?></td>
        <td><?php echo htmlspecialchars($loan['email']); ?></td>
        <td><?php echo number_format((float)$loan['loan_amount'], 2); ?></td>
        <td><?php echo htmlspecialchars($loan['loan_date'] ?? 'N/A'); ?></td>
        <td>
          <?php 
            $status = htmlspecialchars($loan['status'] ?? 'Pending');
            $statusClass = 'status-pending';
            if ($status == 'Approved') {
              $statusClass = 'status-approved';
            } elseif ($status == 'Rejected') {
              $statusClass = 'status-rejected';
            }
            echo "<span class='status-badge $statusClass'>" . $status . "</span>";
          ?>
        </td>
      </tr>
      <?php endwhile; ?>
    </table>
    <?php else: ?>
    <div class="no-loans">
      <p>No loan applications yet.</p>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <a href="logout.php" class="logout">Logout</a>
</body>
</html>
<?php
// Clean up resources
if ($result) {
  $result->free();
}
if ($loans_result) {
  $loans_result->free();
}
$conn->close();
?>
